<?php
/**
 * 銀行口座情報追加レスポンスDTO
 * @author Veritrans, Inc.
 */
class BankAccountAddResponseDto extends AbstractPayNowIdResponseDto {

}

?>
