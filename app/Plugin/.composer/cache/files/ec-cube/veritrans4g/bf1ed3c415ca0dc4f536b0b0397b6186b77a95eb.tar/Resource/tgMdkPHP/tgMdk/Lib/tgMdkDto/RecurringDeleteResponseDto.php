<?php
/**
 * 継続課金情報削除要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class RecurringDeleteResponseDto extends AbstractPayNowIdResponseDto {

}

?>
