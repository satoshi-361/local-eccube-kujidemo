<?php
/**
 * カード情報削除要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class CardInfoDeleteResponseDto extends AbstractPayNowIdResponseDto {

}

?>
