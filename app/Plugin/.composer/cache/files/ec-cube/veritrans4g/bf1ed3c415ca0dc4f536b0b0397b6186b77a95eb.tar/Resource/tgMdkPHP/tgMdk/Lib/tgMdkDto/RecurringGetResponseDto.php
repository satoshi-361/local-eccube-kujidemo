<?php
/**
 * 継続課金情報取得要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class RecurringGetResponseDto extends AbstractPayNowIdResponseDto {

}

?>
