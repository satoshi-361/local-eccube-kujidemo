<?php
/**
 * 会員情報変更要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class AccountUpdateResponseDto extends AbstractPayNowIdResponseDto {

}

?>
