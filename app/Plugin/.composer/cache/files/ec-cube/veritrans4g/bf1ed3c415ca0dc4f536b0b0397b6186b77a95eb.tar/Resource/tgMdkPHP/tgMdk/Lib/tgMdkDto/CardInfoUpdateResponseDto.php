<?php
/**
 * カード情報変更要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class CardInfoUpdateResponseDto extends AbstractPayNowIdResponseDto {

}

?>
