<?php
/**
 * 継続課金情報変更要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class RecurringUpdateResponseDto extends AbstractPayNowIdResponseDto {

}

?>
