<?php
/*
 * Copyright (c) 2018 VeriTrans Inc., a Digital Garage company. All rights reserved.
 * http://www.veritrans.co.jp/
 */
namespace Plugin\VeriTrans4G\Form\Type\Shopping;

use Symfony\Component\Form\AbstractType;

class PaymentLINEPayType extends AbstractType
{

}