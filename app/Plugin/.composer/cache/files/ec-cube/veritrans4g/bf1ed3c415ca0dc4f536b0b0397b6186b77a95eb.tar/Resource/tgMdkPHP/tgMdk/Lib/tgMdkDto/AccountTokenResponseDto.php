<?php
/**
 * 会員情報トークン要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class AccountTokenResponseDto extends AbstractPayNowIdResponseDto {

}

?>
