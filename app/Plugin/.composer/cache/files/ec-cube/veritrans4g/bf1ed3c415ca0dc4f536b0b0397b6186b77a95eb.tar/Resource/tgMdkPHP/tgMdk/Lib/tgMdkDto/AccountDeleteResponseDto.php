<?php
/**
 * 会員情報削除要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class AccountDeleteResponseDto extends AbstractPayNowIdResponseDto {

}

?>
