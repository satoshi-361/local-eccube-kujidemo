<?php
/**
 * 会員情報ID紐付要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class AccountLinkResponseDto extends AbstractPayNowIdResponseDto {

}

?>
