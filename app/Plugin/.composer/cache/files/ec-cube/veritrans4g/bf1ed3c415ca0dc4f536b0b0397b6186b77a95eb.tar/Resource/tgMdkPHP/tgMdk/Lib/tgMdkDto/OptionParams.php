<?php
/**
 * 拡張パラメータクラス
 * @author Veritrans, Inc.
 */
class OptionParams {
}
?>
